#!/bin/bash
python /app/app.py "$1" "$2"
