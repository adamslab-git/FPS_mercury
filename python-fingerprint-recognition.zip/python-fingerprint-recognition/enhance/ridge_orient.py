# -*- coding: utf-8 -*-
"""
Created on Tue Apr 19 11:31:54 2016

@author: utkarsh
"""

# RIDGEORIENT - Estimates the local orientation of ridges in a fingerprint
#
# Usage:  orientim = ridge_orient(im, gradientsigma, blocksigma, orientsmoothsigma)
#
# Arguments:
#   im                - A normalised input image.
#   gradientsigma     - Sigma of the derivative of Gaussian used to compute image gradients.
#   blocksigma        - Sigma of the Gaussian weighting used to sum the gradient moments.
#   orientsmoothsigma - Sigma of the Gaussian used to smooth the final orientation vector field.
#                       Optional: if omitted, defaults to 0.
#
# Returns:
#   orientim          - The orientation image in radians.
#                       Orientation values are +ve clockwise along the ridges.
#
# Reference:
#   Original: Raymond Thai (2003)
#   Reworked: Peter Kovesi (2005, 2011)
#   Updated for NumPy >= 1.24 compatibility.

import numpy as np
import cv2
from scipy import ndimage, signal

def ridge_orient(im, gradientsigma, blocksigma, orientsmoothsigma):
    rows, cols = im.shape

    # Calculate image gradients
    sze = int(np.fix(6 * gradientsigma))
    if np.remainder(sze, 2) == 0:
        sze += 1

    gauss = cv2.getGaussianKernel(int(sze), gradientsigma)
    f = gauss @ gauss.T  # Outer product

    fy, fx = np.gradient(f)  # Gradient of Gaussian

    # Apply filters to image
    Gx = signal.convolve2d(im, fx, mode='same')
    Gy = signal.convolve2d(im, fy, mode='same')

    Gxx = np.power(Gx, 2)
    Gyy = np.power(Gy, 2)
    Gxy = Gx * Gy

    # Smooth the covariance data
    sze = int(np.fix(6 * blocksigma))
    if np.remainder(sze, 2) == 0:
        sze += 1

    gauss = cv2.getGaussianKernel(int(sze), blocksigma)
    f = gauss @ gauss.T

    Gxx = ndimage.convolve(Gxx, f)
    Gyy = ndimage.convolve(Gyy, f)
    Gxy = 2 * ndimage.convolve(Gxy, f)

    # Analytic solution of principal direction
    denom = np.sqrt(np.power(Gxy, 2) + np.power((Gxx - Gyy), 2)) + np.finfo(float).eps
    sin2theta = Gxy / denom
    cos2theta = (Gxx - Gyy) / denom

    # Optionally smooth the orientation field
    if orientsmoothsigma:
        sze = int(np.fix(6 * orientsmoothsigma))
        if np.remainder(sze, 2) == 0:
            sze += 1
        gauss = cv2.getGaussianKernel(int(sze), gradientsigma)
        f = gauss @ gauss.T
        cos2theta = ndimage.convolve(cos2theta, f)
        sin2theta = ndimage.convolve(sin2theta, f)

    orientim = np.pi / 2 + np.arctan2(sin2theta, cos2theta) / 2
    return orientim
