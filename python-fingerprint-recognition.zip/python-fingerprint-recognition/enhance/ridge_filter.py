# -*- coding: utf-8 -*-
"""
Created on Fri Apr 22 03:15:03 2016

@author: utkarsh
"""

import numpy as np
import scipy

def ridge_filter(im, orient, freq, kx, ky):
    angleInc = 3
    im = np.double(im)
    rows, cols = im.shape
    newim = np.zeros((rows, cols))

    freq_1d = np.reshape(freq, (1, rows * cols))
    ind = np.where(freq_1d > 0)
    ind = np.array(ind)
    ind = ind[1, :]

    # Round the array of frequencies to the nearest 0.01
    non_zero_elems_in_freq = freq_1d[0][ind]
    non_zero_elems_in_freq = np.double(np.round(non_zero_elems_in_freq * 100)) / 100

    unfreq = np.unique(non_zero_elems_in_freq)

    # Generate filters
    sigmax = 1 / unfreq[0] * kx
    sigmay = 1 / unfreq[0] * ky

    sze = np.round(3 * np.max([sigmax, sigmay]))

    # Cast sze to int for indexing & np.linspace's `num` argument
    sze_int = int(sze)
    num_points = int(2 * sze_int + 1)

    x, y = np.meshgrid(
        np.linspace(-sze_int, sze_int, num_points),
        np.linspace(-sze_int, sze_int, num_points)
    )

    reffilter = np.exp(-(((x ** 2) / (sigmax ** 2) + (y ** 2) / (sigmay ** 2)))) * \
                np.cos(2 * np.pi * unfreq[0] * x)

    filt_rows, filt_cols = reffilter.shape
    gabor_filter = np.zeros((int(180 / angleInc), filt_rows, filt_cols))

    for o in range(int(180 / angleInc)):
        # Rotate filter
        rot_filt = scipy.ndimage.rotate(reffilter, -(o * angleInc + 90), reshape=False)
        gabor_filter[o] = rot_filt

    maxsze = sze_int
    temp = freq > 0
    validr, validc = np.where(temp)

    temp1 = validr > maxsze
    temp2 = validr < rows - maxsze
    temp3 = validc > maxsze
    temp4 = validc < cols - maxsze

    final_temp = temp1 & temp2 & temp3 & temp4
    finalind = np.where(final_temp)

    maxorientindex = np.round(180 / angleInc)
    orientindex = np.round(orient / np.pi * 180 / angleInc)

    for i in range(rows):
        for j in range(cols):
            if orientindex[i][j] < 1:
                orientindex[i][j] += maxorientindex
            if orientindex[i][j] > maxorientindex:
                orientindex[i][j] -= maxorientindex

    finalind_rows, finalind_cols = np.shape(finalind)

    for k in range(finalind_cols):
        r = validr[finalind[0][k]]
        c = validc[finalind[0][k]]

        img_block = im[r - sze_int:r + sze_int + 1, c - sze_int:c + sze_int + 1]
        newim[r][c] = np.sum(img_block * gabor_filter[int(orientindex[r][c]) - 1])

    return newim
