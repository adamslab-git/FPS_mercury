import os
import cv2
import numpy as np
import threading
from queue import Queue
from skimage.morphology import skeletonize

# ---------- Preprocessing ----------
def preprocess_fingerprint(img_path):
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    img = cv2.resize(img, (200, 200))
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(img)
    binary = cv2.adaptiveThreshold(enhanced, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                   cv2.THRESH_BINARY_INV, 11, 2)
    try:
        import cv2.ximgproc as xip
        thinned = xip.thinning(binary)
    except:
        thinned = skeletonize(binary // 255).astype(np.uint8) * 255
    return thinned

# ---------- Minutiae Extraction ----------
def extract_minutiae(skeleton):
    minutiae = []
    rows, cols = skeleton.shape
    padded = np.pad(skeleton, ((1, 1), (1, 1)), mode='constant')
    for i in range(1, rows + 1):
        for j in range(1, cols + 1):
            if padded[i, j] == 255:
                neighbors = [
                    padded[i-1, j], padded[i-1, j+1], padded[i, j+1], padded[i+1, j+1],
                    padded[i+1, j], padded[i+1, j-1], padded[i, j-1], padded[i-1, j-1]
                ]
                transitions = sum((neighbors[k] == 0 and neighbors[(k+1)%8] == 255) for k in range(8))
                if transitions == 1:
                    minutiae.append(('ending', i-1, j-1))
                elif transitions == 3:
                    minutiae.append(('bifurcation', i-1, j-1))
    return minutiae

# ---------- Matching ----------
def match_minutiae(set1, set2, tolerance=10):
    matches = []
    for type1, y1, x1 in set1:
        for type2, y2, x2 in set2:
            if type1 == type2:
                dist = np.sqrt((x1 - x2)**2 + (y1 - y2)**2)
                if dist <= tolerance:
                    matches.append(((type1, y1, x1), (type2, y2, x2)))
                    break
    return matches

# ---------- Worker Thread ----------
def compare_worker(reference_minutiae, file_queue, results, folder_path):
    while not file_queue.empty():
        filename = file_queue.get()
        skeleton = os.path.join(folder_path, filename)

        minutiae = extract_minutiae(skeleton)
        matches = match_minutiae(reference_minutiae, minutiae)
        score = len(matches) / max(len(reference_minutiae), len(minutiae)) * 100 if minutiae else 0
        results.append((filename, score))
        file_queue.task_done()

# ---------- Main ----------
def compare_all(reference_path, folder_path, num_threads=4):
    reference_skeleton = preprocess_fingerprint(reference_path)
    reference_minutiae = extract_minutiae(reference_skeleton)

    file_queue = Queue()
    results = []
    for f in os.listdir(folder_path):
        if f.endswith(".bmp") and f != os.path.basename(reference_path):
            file_queue.put(f)

    threads = []
    for _ in range(num_threads):
        t = threading.Thread(target=compare_worker,
                             args=(reference_minutiae, file_queue, results, folder_path))
        t.start()
        threads.append(t)

    file_queue.join()
    for t in threads:
        t.join()

    results.sort(key=lambda x: x[1], reverse=True)
    for filename, score in results:
        print(f"{filename}: Match Score = {score:.2f}%")

# Run it
reference_image = r"C:\Users\adaml\python-fingerprint-recognition\database\enhanced_thinned_X1__1.bmp"
database_folder = r"C:\Users\adaml\python-fingerprint-recognition\database"
compare_all(reference_image, database_folder)