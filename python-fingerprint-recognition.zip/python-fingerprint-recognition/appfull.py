import cv2
import os
import numpy
import matplotlib.pyplot as plt
from enhance import image_enhance
from skimage.morphology import skeletonize

os.chdir(r"C:\Users\adaml\python-fingerprint-recognition")

#update input image file name -> reference_image
reference_image = r"database/k0_1.bmp"
database_folder = r"database"

def removedot(invertThin):
    temp0 = numpy.array(invertThin[:])
    temp1 = temp0 / 255
    temp2 = numpy.array(temp1)

    filtersize = 6
    W, H = temp0.shape[:2]

    for i in range(W - filtersize):
        for j in range(H - filtersize):
            filter0 = temp1[i:i + filtersize, j:j + filtersize]
            flag = 0
            if sum(filter0[:, 0]) == 0: flag += 1
            if sum(filter0[:, filtersize - 1]) == 0: flag += 1
            if sum(filter0[0, :]) == 0: flag += 1
            if sum(filter0[filtersize - 1, :]) == 0: flag += 1
            if flag > 3:
                temp2[i:i + filtersize, j:j + filtersize] = numpy.zeros((filtersize, filtersize))

    return temp2

def get_descriptors(img):
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    img = clahe.apply(img)
    img = image_enhance.image_enhance(img)
    img = numpy.array(img, dtype=numpy.uint8)

    _, img = cv2.threshold(img, 127, 255, cv2.THRESH_BINARY_INV | cv2.THRESH_OTSU)
    img[img == 255] = 1

    skeleton = skeletonize(img)
    skeleton = numpy.array(skeleton, dtype=numpy.uint8)
    skeleton = removedot(skeleton)

    harris_corners = cv2.cornerHarris(img, 3, 3, 0.04)
    harris_normalized = cv2.normalize(harris_corners, 0, 255, norm_type=cv2.NORM_MINMAX, dtype=cv2.CV_32FC1)
    threshold_harris = 125

    keypoints = []
    for x in range(harris_normalized.shape[0]):
        for y in range(harris_normalized.shape[1]):
            if harris_normalized[x][y] > threshold_harris:
                keypoints.append(cv2.KeyPoint(y, x, 1))

    orb = cv2.ORB_create()
    _, des = orb.compute(img, keypoints)
    return keypoints, des

def compare_images(img1_path, img2_path):
    img1 = cv2.imread(img1_path, cv2.IMREAD_GRAYSCALE)
    img2 = cv2.imread(img2_path, cv2.IMREAD_GRAYSCALE)

    kp1, des1 = get_descriptors(img1)
    kp2, des2 = get_descriptors(img2)

    if des1 is None or des2 is None:
        return 0

    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(bf.match(des1, des2), key=lambda m: m.distance)

    if len(matches) == 0:
        return 0

    match_score = sum(256 - m.distance for m in matches)
    max_possible_score = len(matches) * 256
    match_percentage = (match_score / max_possible_score) * 100

    return match_percentage

def main():
    reference_name = os.path.basename(reference_image)
    print(f"🔍 Comparing against reference: {reference_name}")

    results = []
    for filename in os.listdir(database_folder):
        if filename.lower().endswith((".bmp", ".png")) and filename != reference_name:
            candidate_path = os.path.join(database_folder, filename)
            score = compare_images(reference_image, candidate_path)
            print(f"✅ Compared with {filename} → {score:.2f}% match")
            results.append((filename, score))

    if results:
        best_match = max(results, key=lambda x: x[1])
        print(f"\n🏆 Best match: {best_match[0]} with {best_match[1]:.2f}% similarity")
    else:
        print("\n❌ No matches found.")

if __name__ == "__main__":
    main()